##### network policy
* Network Policies: https://kubernetes.io/docs/concepts/services-networking/network-policies/
