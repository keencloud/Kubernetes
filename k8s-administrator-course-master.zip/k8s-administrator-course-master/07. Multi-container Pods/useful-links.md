##### multi-container pods
* Init Containers: https://kubernetes.io/docs/concepts/workloads/pods/init-containers/
* Sidecar Container: https://kubernetes.io/docs/concepts/workloads/pods/#how-pods-manage-multiple-containers

##### exposing pod data to containers
* Exposing Pod Information: https://kubernetes.io/docs/tasks/inject-data-application/environment-variable-expose-pod-information/
