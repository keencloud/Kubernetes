##### exam tips
* Official Frequently Asked Questions: https://docs.linuxfoundation.org/tc-docs/certification/faq-cka-ckad-cks
* Official Tips: https://docs.linuxfoundation.org/tc-docs/certification/tips-cka-and-ckad
* More Tips & Tricks: https://hackernoon.com/tips-and-tricks-to-pass-certified-kubernetes-application-cka-exam-px13349o
* Kubectl Cheat Sheet: https://kubernetes.io/docs/reference/kubectl/cheatsheet
