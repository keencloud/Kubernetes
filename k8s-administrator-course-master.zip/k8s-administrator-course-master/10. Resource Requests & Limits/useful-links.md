##### resources
* Managing Resources in K8s: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
* Resource Unit in K8s: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/#resource-units-in-kubernetes
