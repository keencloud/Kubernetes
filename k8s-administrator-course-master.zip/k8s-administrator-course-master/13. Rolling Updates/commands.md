##### rollout commands
    kubectl rollout history deployment/{depl-name}
    kubectl rollout undo deployment/{depl-name}
    kubectl rollout status deployment/{depl-name}
