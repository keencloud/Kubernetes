##### replicaset
* ReplicaSet: https://kubernetes.io/docs/concepts/workloads/controllers/replicaset/

##### deployment upgrade strategies
* Deployment Strategies: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#strategy
* Rolling Update: https://kubernetes.io/docs/tutorials/kubernetes-basics/update/update-intro/

