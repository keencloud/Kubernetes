##### contexts
* Configure Access to multiple clusters: https://kubernetes.io/docs/tasks/access-application-cluster/configure-access-multiple-clusters/
* Context: https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/#context
* kubectl config subcommand: https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands#config
